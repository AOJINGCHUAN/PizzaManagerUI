﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
namespace libraryManager
{
    public class Manager
    {
        /// <summary>
        /// Create list for Books and DVDs
        /// </summary>
        List<string> book = new List<string>();
        List<string> dvd = new List<string>();
        List<string> mem = new List<string>();
 
        public void addMembers()
        {
            Console.WriteLine("How many members you wanna add");
            int numMembers = Convert.ToInt32(Console.ReadLine());
            int i;
            for (i = 0; i < numMembers; i++)
            {
                Console.WriteLine("Please enter the memebr's name");
                string strTitle = Console.ReadLine();
                Console.WriteLine("Please enter the member's ID");
                int numISBN = Convert.ToInt32(Console.ReadLine());
                string bookinfo = "The member's name is "+ strTitle + ", The members's ID" + numISBN;
                mem.Add(bookinfo);
            }
        }

        public void removeMembers()
        {
            Console.WriteLine("Which member you wanna remove,please enter the index: ");
            int removeNum = Convert.ToInt32(Console.ReadLine());
            mem.RemoveAt(removeNum);
        }

        public void listMembers()
        {
            foreach (string s in mem)
            {
                Console.WriteLine(s);
            }
        }

    
        public void addBooks()
        {
            Console.WriteLine("How many books you wanna add");
            int numBooks = Convert.ToInt32(Console.ReadLine());
            int i;
            for (i = 0; i < numBooks; i++)
            {
                Console.WriteLine("Please enter the title");
                string strTitle = Console.ReadLine();
                Console.WriteLine("Please enter the author");
                string strAuthor = Console.ReadLine();
                Console.WriteLine("Please enter the ISBN number");
                int numISBN = Convert.ToInt32(Console.ReadLine());
                string bookinfo = "The book's title is " + strTitle + "," + "The author name is " + strAuthor + ",The ISBN number is " + numISBN;
                book.Add(bookinfo);
                //book.Add(new Books(strTitle, strAuthor, numISBN));
            }
        }

        public void removeBooks()
        {
            Console.WriteLine("Which book you wanna remove,please enter the index: ");
            int removeNum = Convert.ToInt32(Console.ReadLine());
            book.RemoveAt(removeNum);

        }

        public void listBooks()
        {
            foreach (string s in book)
            {
                Console.WriteLine(s);
            }
        }

        //public void searchBooks()
        //{

        //}

        public void addDVDs()
        {
            Console.WriteLine("How many dvds you wanna add");
            int numDVDs = Convert.ToInt32(Console.ReadLine());
            int i;
            for (i = 0; i < numDVDs; i++)
            {
                Console.WriteLine("Please enter the title");
                string strTitle = Console.ReadLine();
                Console.WriteLine("Please enter the author");
                string strAuthor = Console.ReadLine();
                string bookinfo = "The DVD's title is "+ strTitle + " The director is "+ strAuthor;
                dvd.Add(bookinfo);
            }
        }

        public void removeDVDs()
        {
            Console.WriteLine("Which dvd you wanna remove,please enter the index: ");
            int removeNum = Convert.ToInt32(Console.ReadLine());
            dvd.RemoveAt(removeNum);
        }

        public void listDVDs()
        {
            foreach (string s in dvd)
            {
                Console.WriteLine(s);
            }
        }

        //public void searchDVDs()
        //{

        //}

        public void createLoan()
        {
            Console.WriteLine("Create a loan for a members, please choose the index:");
            
        }

        public void closeLoan()
        {

        }

        public void listLoan()
        {

        }

        public void generatePayment()
        {

        }

    }
}
