﻿using System;

namespace libraryManager
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager man = new Manager();
            int command = 0;
            while (command!=10)
            {
                Console.WriteLine("Enter the corresponding number according to the command");
                Console.WriteLine("Add Member --> 1;Remove Member --> 2;List Member --> 3;Add Books --> 4;Remove Books --> 5;" +
                    "List Books --> 6;Add DVDs --> 7;Remove DVDs --> 8;List DVDs --> 9;" +
                    "Exit --> 10;");
                command = Convert.ToInt32(Console.ReadLine());

                switch (command)
                {
                    case 1:
                        man.addMembers();
                        break;
                    case 2:
                        man.removeMembers();
                        break;
                    case 3:
                        man.listMembers();
                        break;
                    case 4:
                        man.addBooks();
                        break;
                    case 5:
                        man.removeBooks();
                        break;
                    case 6:
                        man.listBooks();
                        break;
                    case 7:
                        man.addDVDs();
                        break;
                    case 8:
                        man.removeDVDs();
                        break;
                    case 9:
                        man.listDVDs();
                        break;
                    case 10:
                        break;
                    default:
                        Console.WriteLine("Invalid selection");
                     break;        
                }
            }
            ////Create manager object
            //Manager man = new Manager();
            ////Add books to the library
            //man.addBooks();
            ////List all the books
            //man.listBooks();
            ////Remove books form the library
            //man.removeBooks();
            //man.listBooks();

            //man.addDVDs();
            //man.listDVDs();
            //man.removeDVDs();
            //man.listDVDs();


        }
    }
}
