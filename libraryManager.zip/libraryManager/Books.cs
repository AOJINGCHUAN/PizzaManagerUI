﻿using System;
namespace libraryManager
{
    public class Books:ItemFather
    {
        public Books(string title, string author,int isbn)
            : base(title, author,isbn)
        {

        }

        //public string ISBN
        //{
        //    set;
        //    get;
        //}

    }
}
