﻿using System;
namespace libraryManager
{
    public class ItemFather
    {
        public string Title
        {
            get;
            set;
        }

        public string Author
        {
            get;
            set;
        }

        public int ISBN
        {
            set;
            get;
        }

        public ItemFather(string title, string author,int isbn)
        {
            this.Title = title;
            this.Author = author;
            this.ISBN = isbn;
        }
    }
}
