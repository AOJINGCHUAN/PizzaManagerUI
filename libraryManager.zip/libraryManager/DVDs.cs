﻿using System;
namespace libraryManager
{
    public class DVDs:ItemFather
    {
        public DVDs(string title, string author,int isbn)
            : base(title, author,isbn)
        {

        }

    }
}
